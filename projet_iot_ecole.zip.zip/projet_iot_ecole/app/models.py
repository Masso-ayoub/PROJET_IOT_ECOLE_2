

import os

# Create your models here.
from django.core.mail import send_mail
from django.db import models
class Dht(models.Model):
    temp = models.FloatField(null=True)
    dt = models.DateTimeField(auto_now_add=True,null=True)
    def __str__(self):
         return str(self.temp)

    def save (self,*args,**kwargs):

      if self.temp < 2:
        #envoie message sur telegram
         import telepot
         token = '5921362093:AAEDI74OdSXZKLPHHuW7ZF7tEk6Zz9tHe2I'
         rece_id = 1882716872
         bot = telepot.Bot(token)
         bot.sendMessage(rece_id, 'depassement de temp')
         print(bot.sendMessage(rece_id, 'temp severe.'))
         #envoie message sur mail
         send_mail(
             'température dépasse la normale,' + str(self.temp),
             'anomalie dans la machine',
             'ayoub.masso@ump.ac.ma',
             ['ayoubmasso677@gmail.com'],
             fail_silently=False,
         )
      return super().save(*args,**kwargs)
    def save (self,*args,**kwargs):
        if self.temp > 8:
          # envoie message sur telegram
          import telepot
          token = '5921362093:AAEDI74OdSXZKLPHHuW7ZF7tEk6Zz9tHe2I'
          rece_id = 1882716872
          bot = telepot.Bot(token)
          bot.sendMessage(rece_id, 'depassement de temp')
          print(bot.sendMessage(rece_id, 'temp critique.'))
            #envoie message sur mail
          send_mail(
              'température dépasse la normale,' + str(self.temp),
              'anomalie dans la machine',
              'ayoub.masso@ump.ac.ma',
              ['ayoubmasso677@gmail.com'],
              fail_silently=False,
          )
        return super().save(*args, **kwargs)