from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView
from .models import Dht
from django.template import loader

def Tables(request):
 tab = Dht.objects.all()
 s = {'tab': tab}
 return render(request, 'Tables.html', s)

def chart(request):
 tab = Dht.objects.all()
 s = {'tab': tab}
 return render(request, 'chart.html', s)

def index(request):
 template = loader.get_template('index.html')
 return HttpResponse(template.render())






# Create your views here.




