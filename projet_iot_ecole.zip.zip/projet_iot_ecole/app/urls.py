from . import views,api
from django.urls import path

urlpatterns = [
    path('',views.index,name='home'),

    path('Tables/', views.Tables, name='Tables'),
    path('api/list', api.Dlist, name='DHT11List'),
    path('api/post', api.Dhtviews.as_view(), name='DHT_post'),
    path('chart/', views.chart, name='chart'),


]




